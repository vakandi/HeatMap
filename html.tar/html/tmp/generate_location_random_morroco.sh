#!/bin/bash

# Function to generate random latitude and longitude within specific city boundaries
generate_location() {
    local city=$1
    local lat
    local lng

    case $city in
        Others)
            local min_lat=20.000000
            local max_lat=36.000000
            local min_lng=-17.000000
            local max_lng=-1.000000
            ;;
        *)
            echo "Invalid city"
            return 1
            ;;
    esac

    lat=$(awk -v min=$min_lat -v max=$max_lat 'BEGIN{srand(); printf "%.6f", min+rand()*(max-min)}')
    lng=$(awk -v min=$min_lng -v max=$max_lng 'BEGIN{srand(); printf "%.6f", min+rand()*(max-min)}')

    echo "{ \"lat\": \"$lat\", \"lng\": \"$lng\" }"
}

echo "Choose the number of random locations:"
read choice

# File name to save the locations
file_name="data_random.json"

# Generate locations and save them to the file
echo '{
"datapoints": ' > "$file_name"
echo "[" >> "$file_name"
for ((i=0; i<choice; i++)); do
    # Generate a random city
    cities=("Others")
    random_city=${cities[$RANDOM % ${#cities[@]}]}
    generate_location "$random_city" >> "$file_name"
    if [ $i -lt $((choice-1)) ]; then
        echo "," >> "$file_name"
    fi
done
echo "]" >> "$file_name"
echo "}" >> "$file_name"

echo "Locations generated and saved to $file_name"

