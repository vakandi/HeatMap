<?php
$servername = "localhost";
$username = "root";
$password = "solarroot";
$dbname = "solar_panel";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM solar_panels";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Solar Panel Search</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style2.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCmLMxdjIGcaOXj_5bROtPwE67ZQN5fM04&libraries=visualization&callback=initMap"></script>
    <script src="script.js"></script>
</head>

<body>
    <div class="header">
<form id="search-form" class="search-form" action="search.php" method="post">
        <h1>Solar Panel Search</h1>
    <input type="text" name="manufacturer" placeholder="Manufacturer">
    <input type="text" name="brand" placeholder="Brand">
    <input type="text" name="max_watt_power" placeholder="Max Watt Power">
    <input type="text" name="voltage" placeholder="Voltage">
    <button type="submit" name="submit-search" class="search-button"><img src="https://img.icons8.com/material-outlined/24/000000/search--v1.png"/></button>
</form>
  <a href="tmp/dashboard.html" style="font-size: 25px;" >
    <img src="https://www.iconbunny.com/icons/media/catalog/product/4/0/4092.12-four-cells-joined-icon-iconbunny.jpg" width="35px" height="35px"/>Home</a>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var form = document.getElementById('search-form');
    var resultsDiv = document.getElementById('results-search');

    form.addEventListener('submit', function(e) {
        e.preventDefault(); // Prevent form submission

        var formData = new FormData(form);

        fetch(form.action, {
            method: form.method,
            body: formData
        })
        .then(response => response.text())
	.then(data => {
	    data = '<h2>Search Results :</h2>' + data + '<h3>End of Results </h3>' 
            resultsDiv.innerHTML = data; // Update the div with search results
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });
});
</script>

    </div>

    <div class="container">
        <div class="row">
            <div class="column">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/bootstrap/3.3.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/bootstrap/3.3.0/css/bootstrap-theme.min.css">
<style>
#map-canvas {
        height: 500px;
        width: 100%;
        margin-top: 10px;
        margin-left: 0px;
        margin-right: 0px;
        padding: 0px;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=visualizatvar gradientOutside = [ion"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=visualization"></script>

<script>



$(document).ready(function() {
    var map, heatmapInside, heatmapOutside, infoWindow;
    var hmDataInside = [];
    var hmDataOutside = [];

    function initialize() {
        var mapOptions = {
            zoom: 5,
            center: new google.maps.LatLng(31.7917, -7.0926),
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };

        map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
        infoWindow = new google.maps.InfoWindow();
var polygonCoords = [
    {lat: 35.759, lng: -5.939},   // Tangier
    {lat: 35.759, lng: -0.524},   // Western point
    {lat: 35.260, lng: -0.207},   // Border point
    {lat: 34.985, lng: -1.927},   // Border point
    {lat: 34.528, lng: -2.274},   // Border point
    {lat: 33.998, lng: -2.329},   // Border point
    {lat: 32.967, lng: -4.651},   // Border point
    {lat: 30.236, lng: -4.980},   // Border point
    {lat: 27.666, lng: -6.034},   // Border point
    {lat: 25.003, lng: -6.034},   // Border point
    {lat: 21.420, lng: -13.015},  // Border point
    {lat: 21.420, lng: -17.001},  // Border point
    {lat: 27.666, lng: -17.001},  // Dakhla
    {lat: 27.666, lng: -13.000},  // Laayoune
    {lat: 29.641, lng: -9.702},   // Tarfaya
    {lat: 30.431, lng: -9.634},   // Guelmim
    {lat: 31.639, lng: -8.017},   // Agadir
    {lat: 32.193, lng: -11.021},  // Essaouira
    {lat: 32.876, lng: -10.200},  // Safi
    {lat: 33.343, lng: -9.853},   // El Jadida
    {lat: 33.927, lng: -7.547},   // Casablanca
    {lat: 34.091, lng: -7.570},   // Rabat
    {lat: 34.226, lng: -6.408},   // Taza
    {lat: 34.527, lng: -6.578},   // Al Hoceima
    {lat: 34.985, lng: -6.844},   // Berkane
    {lat: 35.759, lng: -5.939}    // Tangier (closing point)
];

        var boundary = new google.maps.Polygon({
            paths: polygonCoords,
            strokeColor: '#FF0000',
            strokeOpacity: 0,
            strokeWeight: 2,
            fillColor: 'white',
            fillOpacity: 0
        });

        boundary.setMap(map);

        $.getJSON('tmp/data.json').then(function(data) {
            $.each(data.datapoints, function(i, datapoint) {
                var latLng = new google.maps.LatLng(datapoint.lat, datapoint.lng);

                // Check if the data point is within the polygon boundary
                if (google.maps.geometry.poly.containsLocation(latLng, boundary)) {
                    hmDataInside.push({
                        location: latLng,
                        weight: 1
                    });
                } else {
                    hmDataOutside.push({
                        location: latLng,
                        weight: 1
                    });
                }
            });

            if (hmDataInside.length > 0) {
                var pointArrayInside = new google.maps.MVCArray(hmDataInside);

                heatmapInside = new google.maps.visualization.HeatmapLayer({
                    data: pointArrayInside,
                    maxIntensity: 0.8,
                    //maxIntensity: 1,
                    map: map
                });

                var gradient = [
                    'rgb(11, 44, 122)',
                    'rgb(32, 153, 143)',
                    'rgb(0, 219, 0)',
                    'rgb(255, 255, 0)',
                    'rgb(237, 161, 19)',
		    'rgb(194, 82, 60)'
                ];

                heatmapInside.set('gradient', gradient);

                google.maps.event.addListener(heatmapInside, 'click', function(event) {
                    showInfoWindow(event.latLng);
                });
            }

            if (hmDataOutside.length > 0) {
                var pointArrayOutside = new google.maps.MVCArray(hmDataOutside);

                heatmapOutside = new google.maps.visualization.HeatmapLayer({
                    data: pointArrayOutside,
                    maxIntensity: 0,
                    map: map
		});

    var gradientOutside = [
	'rgba(255, 0, 0, 0.1)'
    ];

    heatmapOutside.setOptions({
        gradient: gradientOutside,
        opacity: 0 // Set opacity to 0 to make it invisible
    });

                heatmapOutside.set('opacity', 0); // Set opacity to 0 to make it invisible
            }
        });
    }

        function toggleHeatmap() {
                heatmap.setMap(heatmap.getMap() ? null : map);
        }

        function changeGradient() {
                var gradient = [
                        'rgb(11, 44, 122)',
                        'rgb(32, 153, 143)',
                        'rgb(0, 219, 0)',
                        'rgb(255, 255, 0)',
                        'rgb(237, 161, 19)',
                        'rgb(194, 82, 60)'
                ];

                heatmap.set('gradient', heatmap.get('gradient') ? null : gradient);
        }

        function changeRadius() {
                heatmapInside.set('radius', heatmap.get('radius') ? null : 20);
                heatmapOutside.set('radius', heatmap.get('radius') ? null : 20);
        }

        function changeOpacity() {
                heatmap.set('opacity', heatmap.get('opacity') ? null : 0.25);
        }

        function showInfoWindow(latLng) {
          var locationData = {
            name: 'Location Name',
            address: 'Location Address',
            description: 'Location Description'
          };

          // Create HTML content for the info window
          var content =
            '<div>' +
            '<h3>' + locationData.name + '</h3>' +
            '<p>' + locationData.address + '</p>' +
            '<p>' + locationData.description + '</p>' +
            '</div>';

          // Set the content and open the info window
          infoWindow.setContent(content);
          infoWindow.setPosition(latLng);
          infoWindow.open(map);
        }

        $("#toggle-heatmap").click(function() {
                toggleHeatmap();
        });

        $("#change-radius").click(function() {
                changeRadius();
        });

        $("#change-opacity").click(function() {
                changeOpacity();
        });


    google.maps.event.addDomListener(window, 'load', initialize);
});
</script>

<div class="container">
        <ul class="nav nav-pills" role="tablist">
                <li role="presentation" class="dropdown">
		   <!--    
 <a class="dropdown-toggle" data-toggle="dropdown" href="#">Select Dataset <span class="caret"></span></a>
-->
                        <ul id="menu1" class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Dataset 1</a></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Dataset 2</a></li>
                                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Dataset 3</a></li>
                        </ul>
                </li>
        <li role="presentation"><a id="toggle-heatmap" href="#">Disable Heatmap</a></li>
        <li role="presentation"><a id="change-gradient" href="#">Change Gradient</a></li>
        <li role="presentation"><a id="change-radius" href="#">Change Radius</a></li>
        <li role="presentation"><a id="change-opacity" href="#">Change Opacity</a></li>


	</ul>
        <div id="map-canvas"></div>
</div>




	    </div>


<div id="results-search">
</div>

<div class="column">
    <table id="panelTable">
        <thead>
            <tr>
                <th>Manufacturer</th>
                <th>Brand</th>
                <th>Max Watt Power</th>
                <th>Voltage</th>
            </tr>
        </thead>
	
	<tbody>
<?php
if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["manufacturer"] . "</td>";
        echo "<td>" . $row["brand"] . "</td>";
        echo "<td>" . $row["max_watt_power"] . "</td>";
        echo "<td>" . $row["voltage"] . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='4'>0 results</td></tr>";
}
$conn->close();
?>



        </tbody>
    </table>
</div>

        </div>
    </div>
</body>
</html>


