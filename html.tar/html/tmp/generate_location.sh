#!/bin/bash

# Function to generate random latitude and longitude within Morocco's boundaries
generate_location() {
    local min_lat=27.666039
    local max_lat=36.041649
    local min_lng=-13.172107
    local max_lng=-0.998842

    local lat=$(awk -v min=$min_lat -v max=$max_lat 'BEGIN{srand(); printf "%.6f", min+rand()*(max-min)}')
    local lng=$(awk -v min=$min_lng -v max=$max_lng 'BEGIN{srand(); printf "%.6f", min+rand()*(max-min)}')

    echo "{ \"lat\": \"$lat\", \"lng\": \"$lng\" }"
}

echo -e "Choose the number of random location:\n"
read choice

# Number of locations to generate
#num_locations=80
num_locations=$choice

# File name to save the locations
file_name="locations.json"

# Generate locations and save them to the file
echo '{
"datapoints": ' > "$file_name"
echo "[" >> "$file_name"
for ((i=0; i<num_locations; i++)); do
    generate_location >> "$file_name"
    if [ $i -lt $((num_locations-1)) ]; then
        echo "," >> "$file_name"
    fi
done
echo "]" >> "$file_name"
echo "}" >> "$file_name"

echo "Locations generated and saved to $file_name"


