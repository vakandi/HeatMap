/* General styles */
body {
  margin: 0;
  padding: 0;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

/* Header styles */
.header {
  text-align: center;
}

.search-form {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 20px;
}

.search-form input[type="text"],
.search-form button {
  padding: 5px 10px;
  font-size: 14px;
}

/* Table styles */
#panelTable {
  width: 100%;
  border-collapse: collapse;
  font-family: Arial, sans-serif;
}

#panelTable th,
#panelTable td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

#panelTable th {
  background-color: #f2f2f2;
}

#panelTable tbody tr:nth-child(even) {
  background-color: #f9f9f9;
}

#panelTable tbody tr:hover {
  background-color: #e6e6e6;
}

/* Map styles */
#map-canvas {
  height: 500px;
  width: 100%;
  margin-top: 10px;
  margin-left: 0px;
  margin-right: 0px;
  padding: 0px;
}

/* Result search styles */
#results-search {
  margin-top: 20px;
}

/* Column styles */
.column {
  width: 50%;
  display: inline-block;
  vertical-align: top;
}

.column input[type="text"] {
  width: 100%;
  padding: 5px 10px;
  font-size: 14px;
}

/* Navigation styles */
ul.nav-pills li {
  display: inline;
}

ul.nav-pills li a {
  padding: 5px 10px;
  color: #333;
}

ul.nav-pills li.active a,
ul.nav-pills li a:hover {
  background-color: #f2f2f2;
}

/* Heatmap controls styles */
#heatmap-controls {
  margin-bottom: 20px;
}

#heatmap-controls button {
  margin-right: 5px;
}

/* Additional styles */
h1,
h2,
h3 {
  font-family: Arial, sans-serif;
  margin-top: 0;
  margin-bottom: 10px;
}


