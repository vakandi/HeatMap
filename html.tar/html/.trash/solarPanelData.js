var solarPanelData = 
$(cat /app/autogpt/auto_gpt_workspace/heatmap/data.js | sed s//\/g | sed s//\/g)
;
