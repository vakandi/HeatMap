<?php
$servername = "localhost";
$username = "root";
$password = "solarroot";
$dbname = "solar_panel";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM solar_panels";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Solar Panel Search</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="https://maps.googleapis.com/maps/api/js?key=YOURAPIKEY&libraries=visualization"></script>
    <script src="script.js"></script>
</head>


<body>
    <div class="header">
        <h1>Solar Panel Search</h1>
        <form id="search-form" class="search-form" action="search.php" method="post">
            <input type="text" name="manufacturer" placeholder="Manufacturer">
            <input type="text" name="brand" placeholder="Brand">
            <input type="text" name="max_watt_power" placeholder="Max Watt Power">
            <input type="text" name="voltage" placeholder="Voltage">
            <button type="submit" name="submit-search"><img src="https://img.icons8.com/material-outlined/24/000000/search--v1.png"/></button>
	</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var form = document.getElementById('search-form');
    var resultsDiv = document.getElementById('results-search');

    form.addEventListener('submit', function(e) {
        e.preventDefault(); // Prevent form submission

        var formData = new FormData(form);

        fetch(form.action, {
            method: form.method,
            body: formData
        })
        .then(response => response.text())
	.then(data => {
	    data = '<h2>Search Results :</h2>' + data + '<h3>End of Results </h3>' 
            resultsDiv.innerHTML = data; // Update the div with search results
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });
});
</script>

    </div>

    <div class="container">
        <div class="row">
            <div class="column">
	   

<link rel="stylesheet" href="https://cdn.jsdelivr.net/bootstrap/3.3.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/bootstrap/3.3.0/css/bootstrap-theme.min.css">
<style>
#map-canvas {
        height: 500px;
        width: 100%;
        margin-top: 10px;
        margin-left: 0px;
        margin-right: 0px;
        padding: 0px;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=visualization"></script>
<script>
$(document).ready(function() {
        var map, pointarray, heatmap;

        var hmData = [];

        function initialize() {
                var mapOptions = {
                        zoom: 4,
                        center: new google.maps.LatLng(41.850033, -87.6500523),
                        mapTypeId: google.maps.MapTypeId.ROADMAP
                };

                map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
                var geocoder = new google.maps.Geocoder();

                geocoder.geocode({'address': 'US'}, function(results, status) {
                        var ne = results[0].geometry.viewport.getNorthEast();
                        var sw = results[0].geometry.viewport.getSouthWest();
                        map.fitBounds(results[0].geometry.viewport);
                });
          
                $.getJSON('tmp/data.json').then(function(data) {
                        $.each(data.datapoints, function(i, datapoint) {
                                hmData.push({
                                        location: new google.maps.LatLng(datapoint.lat, datapoint.lng),
                                        weight: 1
                                });
                        });

                        var pointArray = new google.maps.MVCArray(hmData);

                        heatmap = new google.maps.visualization.HeatmapLayer({
                                data: pointArray,
                                maxIntensity: 1
                        });

                        heatmap.setMap(map);
                });
        }



        function toggleHeatmap() {
                heatmap.setMap(heatmap.getMap() ? null : map);
        }

        function changeGradient() {
                var gradient = [
                        'rgba(0, 255, 255, 0)',
                        'rgba(0, 255, 255, 1)',
                        'rgba(0, 191, 255, 1)',
                        'rgba(0, 127, 255, 1)',
                        'rgba(0, 63, 255, 1)',
                        'rgba(0, 0, 255, 1)',
                        'rgba(0, 0, 223, 1)',
                        'rgba(0, 0, 191, 1)',
                        'rgba(0, 0, 159, 1)',
                        'rgba(0, 0, 127, 1)',
                        'rgba(63, 0, 91, 1)',
                        'rgba(127, 0, 63, 1)',
                        'rgba(191, 0, 31, 1)',
                        'rgba(255, 0, 0, 1)'
                ]

                heatmap.set('gradient', heatmap.get('gradient') ? null : gradient);
        }

        function changeRadius() {
                heatmap.set('radius', heatmap.get('radius') ? null : 20);
        }

        function changeOpacity() {
                heatmap.set('opacity', heatmap.get('opacity') ? null : 0.25);
        }

        $("#toggle-heatmap").click(function() {
                toggleHeatmap();
        });

        $("#change-gradient").click(function() {
                changeGradient();
        });

        $("#change-radius").click(function() {
                changeRadius();
        });

        $("#change-opacity").click(function() {
                changeOpacity();
        });

google.maps.event.addDomListener(window, 'load', initialize);
});
</script>

<div class="container">
        <ul class="nav nav-pills" role="tablist">
                <li role="presentation"><a href="tmp/dashboard.html">Home</a></li>
                <li role="presentation" class="dropdown">
		   <!--    
 <a class="dropdown-toggle" data-toggle="dropdown" href="#">Select Dataset <span class="caret"></span></a>
-->
                        <ul id="menu1" class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Dataset 1</a></li>
                        <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Dataset 2</a></li>
                                <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Dataset 3</a></li>
                        </ul>
                </li>
                <li role="presentation"><a id="toggle-heatmap" href="#">Toggle Heatmap</a></li>
                <li role="presentation"><a id="change-gradient" href="#">Change Gradient</a></li>
                <li role="presentation"><a id="change-radius" href="#">Change Radius</a></li>
                <li role="presentation"><a id="change-opacity" href="#">Change Opacity</a></li>
        </ul>
        <div id="map-canvas"></div>
        <p>Currently showing: <strong>Q1, 2015</strong>&nbsp;&nbsp;Data points displayed: <strong>8,478</strong>
</div>




	    </div>

<div id="results-search">
</div>

<div class="column">
    <table id="panelTable">
        <thead>
            <tr>
                <th>Manufacturer</th>
                <th>Brand</th>
                <th>Max Watt Power</th>
                <th>Voltage</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                // output data of each row
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["manufacturer"] . "</td>";
                    echo "<td>" . $row["brand"] . "</td>";
                    echo "<td>" . $row["max_watt_power"] . "</td>";
                    echo "<td>" . $row["voltage"] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>0 results</td></tr>";
            }
            $conn->close();
            ?>
        </tbody>
    </table>
</div>


        </div>
    </div>
</body>
</html>

